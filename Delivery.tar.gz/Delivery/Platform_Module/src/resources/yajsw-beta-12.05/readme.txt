yajsw-beta-12.05

    * Bug: java app arguments bad sort

NOTE: Windows: If you have installed java 8 and an older version on the same machine: set the configuration properties 
				wrapper.java.command = <full path to java>
				wrapper.ntservice.java.command = <full path to java>
