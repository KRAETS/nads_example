import dummy_data_retrieval as dr

def main():
    dr.store_result("ssh","today","hola","hola2")

if __name__ == '__main__':
    main()