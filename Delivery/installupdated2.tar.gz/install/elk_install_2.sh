#!/bin/bash
wget -qO - https://packages.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -
echo "deb http://packages.elastic.co/elasticsearch/2.x/debian stable main" | sudo tee -a /etc/apt/sources.list.d/elasticsearch-2.x.list
sudo apt-get update
sudo apt-get -y install elasticsearch=2.2.1
sudo cp -f ./elasticsearch.yml /etc/elasticsearch/
sudo service elasticsearch restart
sudo update-rc.d elasticsearch defaults 95 10
sudo /usr/share/elasticsearch/bin/plugin install file:./elasticsearch-sql-2.2.1.zip
echo "deb http://packages.elastic.co/kibana/4.4/debian stable main" | sudo tee -a /etc/apt/sources.list.d/kibana-4.4.x.list
sudo apt-get update
sudo apt-get -y install kibana
sudo cp -f ./kibana.yml /opt/kibana/config/
sudo update-rc.d kibana defaults 96 9
sudo service kibana start
sudo apt-get install nginx apache2-utils
sudo htpasswd -c /etc/nginx/htpasswd.users kibanaadmin
sudo cp -f ./default /etc/nginx/sites-available/
sudo mkdir -p /var/www/html
sudo cp -r ./sqlparser /var/www/html/
sudo service nginx restart
echo 'deb http://packages.elastic.co/logstash/2.2/debian stable main' | sudo tee /etc/apt/sources.list.d/logstash-2.2.x.list
sudo apt-get update
sudo apt-get install logstash
sudo mkdir -p /etc/pki/tls/certs
sudo mkdir /etc/pki/tls/private
sudo cp -f ./openssl.cnf /etc/ssl
cd /etc/pki/tls
sudo openssl req -config /etc/ssl/openssl.cnf -x509 -days 3650 -batch -nodes -newkey rsa:2048 -keyout private/logstash-forwarder.key -out certs/logstash-forwarder.crt
cd ~/Downloads/install
sudo cp -f 02-beats-input.conf /etc/logstash/conf.d/
sudo cp -f 30-elasticsearch-output.conf /etc/logstash/conf.d/
sudo cp -f 10-syslog-filter.conf /etc/logstash/conf.d/
sudo service logstash restart
sudo update-rc.d logstash defaults 96 9
sudo apt-get install php5
sudo apt-get install php5-fpm
sudo apt-get install libsnmp-dev snmp-mibs-downloader
sudo apt-get install python-pip python-dev build-essential
sudo pip install easysnmp
