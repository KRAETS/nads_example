import re, signal
import time, json, sys
import os.path

while True:
	ips = sys.argv[1]
	print "is is working"
	print ips
	ips = sys.argv[2]
	print ips