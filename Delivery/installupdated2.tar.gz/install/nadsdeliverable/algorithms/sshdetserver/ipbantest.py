import ipblocksys as ip_tools


if __name__ == '__main__':
    ip_tools.block("136.145.59.140")
