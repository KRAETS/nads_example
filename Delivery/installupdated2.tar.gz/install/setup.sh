#!/bin/bash
yum -y install git
yum -y install net-snmp net-snmp-utils
yum -y install net-snmp-devel
yum -y install gcc python-devel
yum -y install epel-release
yum -y install python-pip
yum groupinstall "Development Tools" "Development Libraries"
yum -y install python-devel libxml2-devel libxml2 libxslt-devel libxslt xmlsec1 xmlsec1-openssl
yum -y install zlib-devel
pip install -r ./requirements.txt
