#!/bin/bash
sudo apt-get install snmp
sudo apt-get -y install libxml2-dev libxslt1-dev python-dev
sudo apt-get install zlib1g-dev
sudo apt-get -y install python-pip python-dev build-essential
sudo easy_install --upgrade pip
sudo pip install -r requirements.txt
sudo add-apt-repository -y ppa:webupd8team/java
sudo apt-get install software-properties-common
sudo echo "deb http://ppa.launchpad.net/webupd8team/java/ubuntu trusty main
deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu trusty main"> /etc/apt/sources.list.d/java-8-debian.list
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys EEA14886
sudo apt-get update
sudo apt-get -y install oracle-java8-installer
sudo apt-get install libsnmp-dev snmp-mibs-downloader
sudo pip install easysnmp
