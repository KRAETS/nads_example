#!/bin/bash
sudo apt-get install snmp
sudo apt-get install git
sudo apt-get install libxml2-dev libxslt1-dev python-dev
sudo apt-get install zlib1g-dev
sudo apt-get install python-pip python-dev build-essential
sudo pip install -r requirements.txt
sudo add-apt-repository -y ppa:webupd8team/java
sudo apt-get update
sudo apt-get -y install oracle-java8-installer
