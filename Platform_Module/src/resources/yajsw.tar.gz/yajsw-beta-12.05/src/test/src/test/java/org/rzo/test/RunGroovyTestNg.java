package org.rzo.test;

import java.util.List;

// boot yajsw, load groovy test files and run the tests
public class RunGroovyTestNg
{
	
	static List loadGroovyScripts(String path)
	{
		return null;
	}
	
	public static void main(String[] args)
	{
		
	}

}
